import 'package:flutter/material.dart';

const kSizedBoxW4 = SizedBox(
  width: 4,
);

const kSizedBoxW10 = SizedBox(
  width: 10,
);

const kSizedBoxW12 = SizedBox(
  width: 12,
);

const kSizedBoxW15 = SizedBox(
  width: 15,
);

const kSizedBoxW25 = SizedBox(
  width: 25,
);

const kSizedBoxW50 = SizedBox(
  width: 50,
);

const kSizedBoxH2 = SizedBox(
  height: 2,
);

const kSizedBoxH3 = SizedBox(
  height: 3,
);

const kSizedBoxH4 = SizedBox(
  height: 4,
);

const kSizedBoxH6 = SizedBox(
  height: 6,
);

const kSizedBoxH8 = SizedBox(
  height: 8,
);

const kSizedBoxH10 = SizedBox(
  height: 10,
);

const kSizedBoxH12 = SizedBox(
  height: 12,
);

const kSizedBoxH15 = SizedBox(
  height: 15,
);

const kSizedBoxH20 = SizedBox(
  height: 20,
);

const kSizedBoxH35 = SizedBox(
  height: 35,
);

const kSizedBoxH40 = SizedBox(
  height: 40,
);

const kSizedBoxH50 = SizedBox(
  height: 50,
);

const kSizedBoxH60 = SizedBox(
  height: 60,
);
