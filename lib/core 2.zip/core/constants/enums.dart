enum CalendarTabs { meeting, events, schedule, holiday }

enum ChatType { hod, employee }

enum ReportsDropDown { payment, advance, quit, logout }

enum PaySlipType { image, pdf }

enum CheckInOutStatus { checkIn, checkOut, qrCheckIn, qrCheckOut, idle }

enum PaymentMethods { windcave, mpaisa, mycash }

enum SharingOrDownloading { sharing, downloading, idle }
