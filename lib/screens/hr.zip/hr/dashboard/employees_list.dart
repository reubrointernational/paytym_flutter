import 'package:flutter/material.dart';
import 'package:paytym/core/colors/colors.dart';
import 'package:paytym/screens/hr/dashboard/widgets/app_bar.dart';

class HrEmployeesList extends StatelessWidget {
  const HrEmployeesList({super.key});

  static List<Map<String, dynamic>> employeesLists = [
    {
      'id': '6386282927',
      'name': 'Akhil Reubro',
      'project': 'paytym',
      'branch': 'Branch',
      'check_in': '9:00 AM',
      'check_out': '6:00 PM',
    },
    {
      'id': '402921927',
      'name': 'Robin Reubro',
      'project': 'paytym',
      'branch': 'Branch',
      'check_in': '9:00 AM',
      'check_out': '6:00 PM',
    },
    {
      'id': '6388882927',
      'name': 'Sreehari Reubro',
      'project': 'jobtym',
      'branch': 'Branch',
      'check_in': '9:00 AM',
      'check_out': '6:00 PM',
    },
    {
      'id': '4993483927',
      'name': 'Sooraj Reubro',
      'project': 'jobtym',
      'branch': 'Branch',
      'check_in': '9:00 AM',
      'check_out': '6:00 PM',
    },
    {
      'id': '94842927',
      'name': 'Sreejith Reubro',
      'project': 'paytym',
      'branch': 'Branch',
      'check_in': '9:00 AM',
      'check_out': '6:00 PM',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: CustomColors.lightBlueColor,
      
      body: SafeArea(
        child: Column(children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(18, 0, 18, 8),
            child: HrAppBar(),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Container(
                height: MediaQuery.of(context).size.height * 0.8,
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                decoration: BoxDecoration(
                  color: CustomColors.whiteCardColor,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: ListView.builder(
                  itemCount: employeesLists.length,
                  itemBuilder: (context, index) {
                    final employees = employeesLists[index];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: Card(
                        shape: RoundedRectangleBorder(
                          side:
                              BorderSide(width: 1, color: Colors.grey.shade300),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxHeight: 90),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 12),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "ID: ${employees['id']!}",
                                      style: TextStyle(
                                        color: Colors.grey.shade600,
                                        fontSize: 13,
                                      ),
                                    ),
                                    Text(
                                      employees['name']!,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    RichText(
                                        text: TextSpan(
                                            text: 'Project: ',
                                            style: const TextStyle(
                                              fontSize: 11.8,
                                              fontWeight: FontWeight.w500,
                                              color: Colors.black,
                                            ),
                                            children: [
                                          TextSpan(
                                            text: '${employees['project']!}',
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: Colors.grey.shade600,
                                            ),
                                          ),
                                        ])),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      employees['branch']!,
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.grey.shade600,
                                      ),
                                    ),
                                    RichText(
                                        text: TextSpan(
                                            text: 'IN: ',
                                            style: const TextStyle(
                                              fontSize: 11.8,
                                              fontWeight: FontWeight.w500,
                                              color:
                                                  CustomColors.lightBlueColor,
                                            ),
                                            children: [
                                          TextSpan(
                                            text: employees['check_in']!,
                                            style: const TextStyle(
                                              fontSize: 12,
                                              color: Colors.black,
                                            ),
                                          ),
                                        ])),
                                    RichText(
                                        text: TextSpan(
                                            text: 'OUT: ',
                                            style: const TextStyle(
                                              fontSize: 11.8,
                                              fontWeight: FontWeight.w500,
                                              color:
                                                  CustomColors.lightBlueColor,
                                            ),
                                            children: [
                                          TextSpan(
                                            text: employees['check_out']!,
                                            style: const TextStyle(
                                              fontSize: 12,
                                              color: Colors.black,
                                            ),
                                          ),
                                        ])),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
