import 'package:get/get.dart';

class HRDashboardController extends GetxController {
  final selectedDepartment = ''.obs;
  final selectedBranch = ''.obs;
}
