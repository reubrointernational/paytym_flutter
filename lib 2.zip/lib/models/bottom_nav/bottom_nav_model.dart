import 'package:flutter/cupertino.dart';

class BottomNavModel {
  final String label;
  final IconData icon;
  BottomNavModel(this.label, this.icon);
}
