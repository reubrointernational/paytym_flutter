import 'package:flutter/material.dart';

class CalendarModel {
  final String date;
  final String day;
  final Color textColor;
  final Color bgColor;
  CalendarModel(this.date, this.day, this.textColor, this.bgColor);
}
