import '../../core/constants/enums.dart';

class CalendarDropDownModel {
  String label = '';
  CalendarTabs dropDownItem = CalendarTabs.meeting;
  CalendarDropDownModel(this.label, this.dropDownItem);
}
