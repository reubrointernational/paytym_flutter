import '../../core/constants/enums.dart';

class ReportDropDownModel {
  String label = '';
  ReportsDropDown dropDownItem = ReportsDropDown.advance;
  ReportDropDownModel(this.label, this.dropDownItem);
}
